#pragma once
#include <string>

class APIController;
enum class APIType;
struct WindowConfig;

/*========================================================================

  GameStateMachine - It controls which state to update / render / ext...

========================================================================*/

//  TODO:	This class is where actual game is being created and 
//			GameStateMachine will be virtual class of this class and
//			this class would be renamed to title of the game.

class GameStateMachine
{
private:
	APIController* m_pOwningAPI;
	WindowConfig* m_gameConfig;

public:
	GameStateMachine(APIController* pAPI, const APIType& apiType, const std::string& title, const size_t& width, const size_t& height);
	~GameStateMachine();

	void Init();
	void Update();
	bool ProcessEvents();


};

