#include "GameStateMachine.h"
#include "APIController.h"

GameStateMachine::GameStateMachine(APIController* pAPI, const APIType& apiType, const std::string& title, const size_t& width, const size_t& height)
	:
	m_pOwningAPI(pAPI)
{
	
}

GameStateMachine::~GameStateMachine()
{

}
