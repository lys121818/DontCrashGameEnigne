#include <APIController.h>
#include "GameStateMachine.h"

/*
	READ ME

	Chose Game Api to use with APIController

	- SDL: APIController::API::SDL
	- OpenGL: APIController::API::OpenGL

	APIController is the based API to run the engine

	GameStateMachine is the machine to run the game with the given API from the engine
*/


int main(int argc, char* argv[])
{
	// System Config
	DC_Engine::WindowConfig gameConfig;
	gameConfig.api = DC_Engine::APIType::NONE;
	gameConfig.width = 1024;
	gameConfig.height = 768;
	gameConfig.title = "GAME";

	APIController controlDevice;
	GameStateMachine game(&controlDevice);

	DC_Engine::ActionResult result = controlDevice.Init(gameConfig ,&game);

	if(result == DC_Engine::ActionResult::kSuccess)
		controlDevice.Run();

	controlDevice.Destory();

	return 0;
}