#pragma once
#include <string>

namespace API
{
	enum class Type
	{
		NONE = 0,
		SDL = 1,
		OpenGL,
		DirectX
	};

	enum class ActionResult
	{
		kSuccess = 0,
		kWindowInitFail = 1,
		kWindowCreateFail,
		kAPIInitFail,
	};

	struct WindowConfig
	{
		Type api;
		size_t width = 0;
		size_t height = 0;
		std::string title = "Untitled";
	};
}