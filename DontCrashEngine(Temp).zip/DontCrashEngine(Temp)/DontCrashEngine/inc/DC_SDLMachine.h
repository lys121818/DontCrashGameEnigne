#pragma once
#include "MachineDevice.h"

struct SDL_Window;

class DC_SDLMachine : public DC_Engine::MachineDevice
{
public:
	DC_SDLMachine(const size_t& width, const size_t& height, const std::string& title);

	API::ActionResult Init() override;
	API::ActionResult Destroy() override;

	void Run() override;

private:
	API::ActionResult Create();
	bool ProcessEvents();

private:
	SDL_Window* m_pDCWindow = nullptr;

};

