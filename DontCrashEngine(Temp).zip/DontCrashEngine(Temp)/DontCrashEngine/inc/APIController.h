#pragma once
#include "APIStatus.h"

class GameStateMachine;
class MachineDevice;
class Logger;



/*========================================================================

  APIController - this controls actual API to run Game State

========================================================================*/

class APIController
{
public:
	API::ActionResult Init(const API::WindowConfig& config, GameStateMachine* stateMachine);
	void Run();
	void Destory();

private:
	bool HasAPI();


private:
	API::WindowConfig m_winConfig;
	GameStateMachine* m_pCurrentGame = nullptr;
	MachineDevice* m_pCurrentAPI = nullptr;
	Logger* m_logger = nullptr;
	API::ActionResult m_state;
};

