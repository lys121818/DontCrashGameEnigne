#pragma once
#include <string>
#include "APIStatus.h"


/*========================================================================

  DCWindow - It controls which state to update / render / ext...

========================================================================*/

namespace DC_Engine
{
	class MachineDevice
	{
	protected:
		API::WindowConfig m_config;

	public:
		virtual API::ActionResult Init() = 0;

		virtual void Run() = 0;

		virtual API::ActionResult Destroy() = 0;
		~MachineDevice() = default;

	};
}