#include "DC_OpenGLMachine.h"
#include <iostream>
#include <glfw3.h>

DC_OpenGLMachine::DC_OpenGLMachine(const size_t& width, const size_t& height, const std::string& title)
{
	m_config.title = title;
	m_config.height = height;
	m_config.width = width;
}

DC_Engine::ActionResult DC_OpenGLMachine::Init()
{
	DC_Engine::ActionResult result = DC_Engine::ActionResult::kSuccess;

	// Initialize OpenGL
	if (glfwInit() == 0)
	{
		std::cout << "failed to initialize OpenGL. Error: " << glGetError() << std::endl;
		return DC_Engine::ActionResult::kWindowInitFail;
	}

	// Create windows
	result = Create();

	return result;
}

DC_Engine::ActionResult DC_OpenGLMachine::Destroy()
{
	glfwTerminate();
	return DC_Engine::ActionResult::kSuccess;
}

void DC_OpenGLMachine::Run()
{
	while (!glfwWindowShouldClose(m_pDCWindow))
	{
		//Render
		glClear(GL_COLOR_BUFFER_BIT);

		// Swap front and back buffers
		glfwSwapBuffers(m_pDCWindow);

		// Event handler
		ProcessEvents();
	}
}

DC_Engine::ActionResult DC_OpenGLMachine::Create()
{
	m_pDCWindow = glfwCreateWindow((int)m_config.width, (int)m_config.height, m_config.title.c_str(),NULL,NULL);

	if (m_pDCWindow == nullptr)
	{
		std::cout << "failed to Create Window. Erorr: " << glGetError() << std::endl;
		Destroy();
		return DC_Engine::ActionResult::kWindowCreateFail;
	}


	return DC_Engine::ActionResult::kSuccess;
}

bool DC_OpenGLMachine::ProcessEvents()
{
	glfwPollEvents();

	return true;
}
