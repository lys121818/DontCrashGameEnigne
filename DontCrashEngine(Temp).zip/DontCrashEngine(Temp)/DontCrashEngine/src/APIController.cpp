#include <conio.h>
#include <assert.h>

#include "APIController.h"
#include "Log.h"
#include "DC_OpenGLMachine.h"
#include "DC_SDLMachine.h"

API::ActionResult APIController::Init(const API::WindowConfig& config, GameStateMachine* stateMachine)
{
	m_pCurrentGame = stateMachine;
	m_winConfig = config;

	// Set Log
	m_logger = new DC_Engine::Logger("Log.log");
	assert(m_logger);

	// Set API
	API::ActionResult result = API::ActionResult::kAPIInitFail;

	switch (m_winConfig.api)
	{
		case API::Type::NONE:
		{
			m_logger->LogWarning("API has set to None");
			break;
		}

		case API::Type::SDL:
		{
			result = API::ActionResult::kSuccess;
			m_pCurrentAPI = new DC_SDLMachine(m_winConfig.width, m_winConfig.height, m_winConfig.title);
			break;
		}

		case API::Type::OpenGL:
		{
			result = API::ActionResult::kSuccess;
			m_pCurrentAPI = new DC_OpenGLMachine(m_winConfig.width, m_winConfig.height, m_winConfig.title);
			break;
		}


	default:
		break;
	}

	if(m_winConfig.api != API::Type::NONE)
		m_pCurrentAPI->Init();

	return result;
}

void APIController::Run()
{
	if (!HasAPI())
		return;

	if (m_state == API::ActionResult::kSuccess)
		m_pCurrentAPI->Run();
	else
		m_logger->LogError("It has file to create windows ErrorCode: ", (size_t)m_state);


}

void APIController::Destory()
{
	if (!HasAPI())
		return;

	m_pCurrentAPI->Destroy();

	delete m_pCurrentAPI;
	delete m_logger;

	m_pCurrentGame = nullptr;
	m_pCurrentAPI = nullptr;
	m_logger = nullptr;

}

bool APIController::HasAPI()
{
	if (m_winConfig.api == API::Type::NONE)
	{
		m_logger->LogWarning("Current API is None");
		return false;
	}

	assert(m_pCurrentAPI != nullptr);
	return true;
}
